import * as grpc from '@grpc/grpc-js';
import * as demo_pb from 'js_lib/js_lib_pb/demo_pb.js';
import * as demo_grpc_pb from 'js_lib/js_lib_pb/demo_grpc_pb.js';
