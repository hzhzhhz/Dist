This directory contains a script to generate the nuget.bzl file, which declares the nuget protobuf and grpc dependencies.
